---
name: SURAKSHA 360
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c6c6cc'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#909096'
  outline-variant: '#45464b'
  surface-tint: '#c3c6d3'
  primary: '#c3c6d3'
  on-primary: '#2c303a'
  primary-container: '#090d16'
  on-primary-container: '#777a86'
  inverse-primary: '#5a5e69'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#d0bcff'
  on-tertiary: '#3c0091'
  tertiary-container: '#120037'
  on-tertiary-container: '#8b5cf6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dfe2ef'
  primary-fixed-dim: '#c3c6d3'
  on-primary-fixed: '#181b25'
  on-primary-fixed-variant: '#434751'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-performance, professional SaaS dashboard tailored for emergency monitoring and personal safety. The brand personality is authoritative yet empathetic, balancing calm operational oversight with rapid-response readiness. 

The visual style merges **Minimalism** with **Modern Enterprise** sensibilities, prioritizing zero-latency readability, high-contrast indicators, and low-cognitive-load surfaces. The aesthetic evokes complete reliability—essential for high-stakes safety environments where clarity dictates user trust and decisive action.

## Colors

The foundation of the palette is a deep dark navy blue (`#090D16`), engineered to reduce eye strain in low-light environments while maximizing the luminance of critical data displays. Crisp white (`#FFFFFF`) serves as the primary text color for absolute legibility.

Subtle violet (`#6366F1`) and indigo (`#8B5CF6`) establish interactive hierarchy, denoting active monitoring states, primary navigation elements, and secondary focal points. Emergency red (`#EF4444`) is strictly firewalled for SOS triggers, active distress signals, and critical system failures, ensuring instant visual dominance during high-stress incidents.

## Typography

The typography stack relies exclusively on **Inter** for its systematic, utilitarian neutrality. This ensures unambiguous data consumption across telemetry streams, location coordinates, and status logs. 

For responsiveness, headlines larger than 32px are clamped on mobile viewports to prevent wrapping anomalies. Tracking is slightly tightened on large numerical displays to enhance scannability of safety metrics.

## Layout & Spacing

The layout is built upon a **12-column fluid grid system** designed to adapt seamlessly from dense desktop command centers to mobile field devices. Content panels snap to structured containers with a standard 24px outer margin and 24px gutters.

Spacing follows an 8px baseline grid rhythm. Component padding and element spacing utilize tokens strictly to govern whitespace, ensuring that dense monitoring modules maintain visual breathing room without sacrificing information density.

## Elevation & Depth

Visual hierarchy is communicated primarily through **tonal layering** and **low-contrast outlines** rather than heavy drop shadows. Surfaces elevate through incremental lightness shifts against the deep navy background, utilizing ghost borders (`rgba(255, 255, 255, 0.08)`) to delineate structural boundaries.

Ambient glow effects are reserved exclusively for active SOS states, casting a diffused emergency red shadow to draw immediate operator attention without cluttering the interface.

## Shapes

The shape language employs a **rounded** standard (0.5rem base border radius, scaling up to 1rem for `rounded-lg` and 1.5rem for `rounded-xl`). This softened geometry balances institutional SaaS precision with a human-centric, approachable feel, reducing visual hostility while maintaining clean architectural containers.

## Components

- **Buttons:** Primary actions utilize solid indigo fills (`#6366F1`) with crisp white labels. SOS trigger components must always render in solid emergency red (`#EF4444`) as full-width or prominent anchor elements with high-contrast borders.
- **Chips & Badges:** Pill-shaped status indicators use low-opacity background tints paired with solid semantic text (e.g., green for secure, red for alert, violet for active tracking).
- **Lists:** High-density telemetry and event logs featuring subtle divider lines, alternating row contrast, and clear typographic hierarchy for timestamps and IDs.
- **Checkboxes & Radio Controls:** Custom-styled with deep surface backgrounds, clean 2px borders, and indigo accent fills upon selection.
- **Input Fields:** Outlined containers featuring subtle border highlights on focus and high-contrast placeholder text to ensure rapid data entry during incidents.
- **Cards:** Structured container blocks utilizing tonal surface elevation, rounded corners, and subtle ghost borders to group map telemetry, contact lists, and device status feeds.
- **Emergency Action Bar:** A persistent, high-priority bottom or side dock housing the primary SOS override and quick-dispatch triggers.