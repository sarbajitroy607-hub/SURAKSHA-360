---
name: Suraksha 360
colors:
  surface: '#0c1323'
  surface-dim: '#0c1323'
  surface-bright: '#32394b'
  surface-container-lowest: '#070e1e'
  surface-container-low: '#141b2c'
  surface-container: '#181f30'
  surface-container-high: '#232a3b'
  surface-container-highest: '#2e3446'
  on-surface: '#dce2f9'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dce2f9'
  inverse-on-surface: '#293042'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#ffbcb7'
  on-tertiary: '#68000a'
  tertiary-container: '#ff938c'
  on-tertiary-container: '#8d0012'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#0c1323'
  on-background: '#dce2f9'
  surface-variant: '#2e3446'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-status:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-assurance, premium personal safety and autonomous emergency assistance environment. It balances calm, vigilant authority with instant, friction-free crisis response. The aesthetic merges modern executive software reliability with advanced aerospace telemetry styling—communicating absolute dependability, discreet vigilance, and rapid protective mobilization.

### Target Audience & Tone
Engineered for professionals, families, global travelers, and enterprise duty-of-care administrators requiring mission-critical protection. The interface projects zero-panic clarity, crystalline precision, and continuous operational readiness.

### Visual Style
- **Techno-Atmospheric Depth:** Deep abyssal navy layers paired with illuminated perimeter boundaries and controlled optical field glows.
- **Critical Isolation:** Routine UI elements remain understated and high-contrast, strictly reserving saturated emergency crimson and beacon amber for true alert surfaces and panic mechanisms.
- **Precision Modernism:** Sharp information density, engineered metric callouts, and rounded tactical modules engineered for split-second readability under acute stress.

## Colors

The palette employs deep night navigation values to minimize eye strain and preserve night-adapted vision, accented by electric atmospheric hues for active telemetry and reserved high-intensity signals for SOS alerts.

### Palette Architecture
- **Primary (`#38BDF8` - Electric Cyan):** Designates active telemetry, secure network links, primary confirmations, and responsive focus anchors.
- **Secondary (`#6366F1` - Electric Violet):** Reserved for spatial intelligence badges, premium AI feature modules, secure encryption states, and secondary interactive layers.
- **Tertiary (`#EF4444` - Emergency Crimson):** The mission-critical override tone. Strictly restricted to panic buttons, active threat dispatches, critical health alerts, and emergency contact cancellations. Paired with Amber (`#F59E0B`) for elevated threat warnings.
- **Base Surfaces (`#070E1E`, `#0B172E`, `#0F2042`):** Multi-layered navy midnight tiers that ground the interface and provide true visual depth beneath luminous overlays.
- **Content & Light Slates (`#F8FAFC`, `#E2E8F0`):** Ultra-crisp, glare-free values engineered for legible cards, body copy, and tabular dispatch details.

### Functional States
- **Normal Secure:** Electric Cyan and Violet accents against deep navy containers.
- **Incident Active:** Full-interface escalation where Crimson borders, amber status beacons, and high-visibility alert headers supersede secondary decoration.

## Typography

Typography delivers immediate perceptual stability through distinct functional roles:
- **Headings (Plus Jakarta Sans):** Geometric clarity and commanding presence for hero value statements, telemetry headers, and structural landing checkpoints. Tight letter spacing reinforces technical cohesion.
- **Body & Data (Inter):** Highly legible, neutral sans-serif rendering numerical metrics, security protocols, situational guides, and micro-copy with maximum optical fidelity.
- **Status & Telemetry Labels:** Upper-case, tracking-expanded micro-labels designed for rapid scanning of device battery, satellite connectivity, and geo-fence radius readings.

## Layout & Spacing

The layout is grounded in a 12-column responsive fluid grid designed to support asymmetrical command dashes, real-time live telemetry feeds, and structured product feature matrices.

### Responsive Breakpoints & Rhythms
- **Desktop (1200px+):** 12 columns, `gutter` of 1.5rem, canvas `margin` of 3rem, max-width bounded at 1280px for optimal scanning comfort.
- **Tablet (768px – 1199px):** 8 columns, `gutter` of 1.25rem, canvas `margin` of 2rem. Side-by-side modules collapse to balanced binary blocks.
- **Mobile (Under 768px):** 4 columns, `gutter-mobile` of 1rem, canvas `margin-mobile` of 1.25rem. Interactive controls expand to full touch-surface widths with sticky panic triggers anchored at the ergonomic bottom thumb zone.

### Vertical Cadence
Stack layouts prioritize high breathing room between narrative landing sections (using `space-xl` multipliers) while maintaining dense, tactical information clusters within component containers (leveraging `space-xs` through `space-md`).

## Elevation & Depth

Visual hierarchy is constructed via layered tonal surfaces enriched by luminous edge refraction and targeted luminescence rather than heavy drop shadows.

### Surface Tiers
- **Tier 0 (Canvas Base):** Deepest tone (`#070E1E`), absolute baseline.
- **Tier 1 (Structural Panels):** Midnight core (`#0B172E`) bordered with a subtle 1px border (`#1E293B` at 60% opacity).
- **Tier 2 (Interactive Floating Cards):** Elevated slate navy (`#0F2042`) accompanied by an inset 1px highlight line along the top border (`rgba(255, 255, 255, 0.08)`).
- **Tier 3 (Active Overlays & Modals):** High-density dark glass with `backdrop-filter: blur(16px)` and a dual-tone edge refraction.

### Tactical Glow Architecture
- **Ambient Field Glow:** Subdued radial background halos using primary cyan and secondary violet at 8%–12% opacity to highlight interactive hero clusters.
- **Crisis Luminescence:** Reserved exclusively for active alert states and SOS modules, casting a localized perimeter aura of `#EF4444` (`box-shadow: 0 0 32px rgba(239, 68, 68, 0.35)`).

## Shapes

The geometric framework balances approachable human-centric software with rugged tactical shielding. Corner radiuses follow standard rounded parameters:
- **Base Components (Inputs, Buttons, Badges):** 0.5rem (`rounded`) ensuring friendly touch targeting and precise perimeter definition.
- **Feature Modules & Cards:** 1rem (`rounded-lg`) to contain dense data while maintaining soft boundaries against dark backdrops.
- **Modal Dialogs & Command Panels:** 1.5rem (`rounded-xl`) defining authoritative focal zones.
- **Interactive Triggers (Status Pills, SOS Core):** Continuous rounded caps (`rounded-full`) for toggle chips, telemetry beacons, and the circular primary panic control.

## Components

### Buttons
- **Primary Action (Electric Sky):** Background `#38BDF8`, text `#070E1E` (weight 700). On hover, soft cyan edge glow (`0 0 16px rgba(56, 189, 248, 0.45)`).
- **Secondary Action (Subtle Navy Glass):** Surface `#0F2042`, 1px border `#38BDF8` (30% opacity), text `#F8FAFC`.
- **SOS Critical Emergency Button:** Concentric multi-ring circular button. Background `#EF4444`, text `#FFFFFF`, subtle rhythmic pulse animation. Long-press tactile progress indicator for accidental trigger prevention.

### Cards & Content Modules
- Built on Tier 2 (`#0F2042`) or light contrasting slate (`#F8FAFC` for enterprise trust documentation).
- Dark cards feature an ultra-fine border (`#334155` at 50% opacity), clean inner padding using `space-lg`, and an optional electric violet top hairline.

### Chips & Badges
- **Live Status Chip:** Pill-shaped, background `rgba(56, 189, 248, 0.1)`, text `#38BDF8`, sporting a continuous micro-pulsing green or cyan indicator dot.
- **Alert Level Badge:** Background `rgba(239, 68, 68, 0.15)`, text `#EF4444`, uppercase tracking (`label-status`).

### Input Fields
- Surface `#0B172E` with a 1px border of `#334155`. Text renders in crisp `#F8FAFC` with placeholder text in `#64748B`. Focused state engages an unbroken `#38BDF8` border accompanied by an atmospheric cyan drop glow.

### Real-Time Telemetry Panels (Specialized)
- Monospace-aligned metric grids for battery levels, response team proximity (ETA), and satellite constellation sync.
- Split-second visual indicators with high-contrast numerical readouts.

### Incident Checkboxes & Toggles
- Custom square toggles with 0.25rem corner curves; selected states ignite in `#38BDF8` with a dark verification check. Radio selections utilize glowing concentric rings.