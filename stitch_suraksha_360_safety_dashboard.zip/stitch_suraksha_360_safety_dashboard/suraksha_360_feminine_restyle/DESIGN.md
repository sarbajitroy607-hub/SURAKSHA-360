---
name: Suraksha 360 Feminine Restyle
colors:
  surface: '#171119'
  surface-dim: '#171119'
  surface-bright: '#3e3740'
  surface-container-lowest: '#120c14'
  surface-container-low: '#201922'
  surface-container: '#241d26'
  surface-container-high: '#2e2830'
  surface-container-highest: '#3a323b'
  on-surface: '#ebdfeb'
  on-surface-variant: '#d6c0d3'
  inverse-surface: '#ebdfeb'
  inverse-on-surface: '#352e37'
  outline: '#9f8b9d'
  outline-variant: '#524251'
  surface-tint: '#fbabff'
  primary: '#fbabff'
  on-primary: '#580065'
  primary-container: '#e14ef6'
  on-primary-container: '#4d0059'
  inverse-primary: '#a200ba'
  secondary: '#ffafd3'
  on-secondary: '#620040'
  secondary-container: '#85145a'
  on-secondary-container: '#ff93c8'
  tertiary: '#ffb0cd'
  on-tertiary: '#640039'
  tertiary-container: '#f751a1'
  on-tertiary-container: '#570032'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd6fd'
  primary-fixed-dim: '#fbabff'
  on-primary-fixed: '#36003e'
  on-primary-fixed-variant: '#7c008e'
  secondary-fixed: '#ffd8e7'
  secondary-fixed-dim: '#ffafd3'
  on-secondary-fixed: '#3d0026'
  on-secondary-fixed-variant: '#85145a'
  tertiary-fixed: '#ffd9e4'
  tertiary-fixed-dim: '#ffb0cd'
  on-tertiary-fixed: '#3e0022'
  on-tertiary-fixed-variant: '#8c0053'
  background: '#171119'
  on-background: '#ebdfeb'
  surface-variant: '#3a323b'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a sanctuary of safety and empowerment for women, balancing deep emotional security with resolute strength. The aesthetic merges minimalist clarity with glassmorphic refinement to evoke modern digital protection. 

- **Target Audience:** Women seeking personal safety, wellness, and empowerment tools in a sophisticated, non-intimidating digital space.
- **Emotional Response:** Empathetic, calm, fiercely protected, and elevated.
- **Design Style:** Glassmorphism infused with a high-contrast dark foundation. Translucent layers, vibrant orchid highlights, and tactile rose gold accents create an interface that feels both deeply personal and unshakeable.

## Colors

The palette is anchored by deep rich plum and dark charcoal-rose surfaces that create a protective, low-glare nighttime environment. Accents of soft orchid, vibrant magenta, and rose gold guide the eye with warmth and elegance, while a high-visibility emergency red is reserved strictly for SOS triggers.

- **Primary (`#D946EF`):** Vibrant magenta used for primary interactive states and focal points.
- **Secondary (`#F472B6`):** Soft orchid for supporting actions, active states, and secondary highlights.
- **Tertiary (`#EC4899`):** Rose highlight for subtle gradients and badge backgrounds.
- **Neutrals (`#1A141C` to `#251D29`):** Deep plum and charcoal-rose base surfaces ensuring high-contrast readability.
- **Emergency (`#EF4444`):** Uncompromising red for immediate critical alerts and the persistent SOS mechanism.

## Typography

Typography pairs the welcoming, soft geometric geometry of Plus Jakarta Sans for headings with the crisp, utilitarian legibility of Inter for body copy. 

- **Scale & Hierarchy:** Headings utilize tighter tracking and heavier weights to project confidence, while body sizes remain optimized for instant scanning under high-stress conditions.
- **Responsive Adaptation:** Large headline tokens automatically shift down on mobile viewports to prevent awkward wrapping, ensuring the SOS dashboard and critical status indicators remain entirely above the fold.

## Layout & Spacing

A fluid grid system is employed to adapt seamlessly across mobile devices, tablets, and desktop dashboards. 

- **Layout Model:** 12-column fluid grid on desktop, scaling down to 4 columns on mobile. 
- **Spacing Rhythm:** Based on an 8px foundational scale, translated into tokenized increments (`space-xs` through `space-xl`). Generous outer margins (`margin: 1.5rem`) ensure touch targets never bleed into device edges, maintaining ergonomic safety and breathing room.
- **Reflow Rules:** Complex multi-column safety logs and contact grids collapse into single-column vertical stacks on viewports smaller than 768px.

## Elevation & Depth

Depth is primarily achieved through **Glassmorphism** and **Ambient Tonal Layers**. 

- **Surfaces:** Floating cards and navigation bars use translucent dark charcoal-rose fills (`rgba(37, 29, 41, 0.75)`) paired with a `12px` backdrop blur to establish frosted hierarchy.
- **Borders & Highlights:** Elements are defined by soft, low-contrast outlines in rose gold (`rgba(229, 169, 158, 0.2)`) rather than harsh drop shadows.
- **Emergency State:** The primary SOS trigger breaks the glass paradigm, utilizing a solid, high-intensity emergency red glow to demand immediate tactile interaction.

## Shapes

The shape language relies on a friendly, approachable **Rounded** profile (`roundedness: 2`). 

- **Border Radius:** Standard containers and inputs use `0.5rem` radii, while major structural cards and modals elevate to `1rem` (`rounded-lg`).
- **Pills & Badges:** Interactive chips, status tags, and the primary action buttons use full pill-shaped rounding (`9999px`) to soften the high-contrast dark environment and encourage fluid touch interactions.

## Components

All components integrate the deep plum foundation, glassmorphic surfacing, and vibrant magenta/rose gold accents.

- **Buttons:** Primary actions feature solid vibrant magenta or gradient fills with soft glowing shadows. The emergency SOS button is an unmissable, pulsing red circle. Secondary actions use ghost styles with subtle rose gold borders.
- **Chips:** Pill-shaped filter and status tags featuring translucent dark backgrounds, thin rose gold borders, and soft orchid text.
- **Lists:** Clean rows separated by low-opacity dividers, featuring leading icons in soft orchid and trailing action chevrons.
- **Checkboxes & Radio Buttons:** Custom-styled with deep plum interiors, activating with a bright magenta fill and a crisp checkmark.
- **Input Fields:** Frosted glass input boxes with high-contrast text, clear placeholder states, and glowing magenta focus rings.
- **Cards:** Elevated glass containers holding safety status summaries, emergency contact shortcuts, and route histories, framed by delicate rose gold outlines.
- **Specialized Components:** Includes live location map wrappers with floating glass control docks, safety check-in countdown timers, and discrete decoy-mode toggle switches.